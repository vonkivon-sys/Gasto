# 💸 Mis Gastos Diarios — PWA

App para registrar gastos e ingresos diarios, con login por usuario.

---

## 🚀 Cómo subir a Vercel (5 minutos)

### Paso 1 — Crear cuenta en GitHub
1. Entrá a https://github.com y creá una cuenta gratis (si no tenés)

### Paso 2 — Subir el proyecto a GitHub
1. Entrá a https://github.com/new
2. Nombre del repo: `mis-gastos`
3. Hacé click en **Create repository**
4. Seguí las instrucciones para subir los archivos (o usá GitHub Desktop)

### Paso 3 — Conectar con Vercel
1. Entrá a https://vercel.com y creá cuenta con tu cuenta de GitHub
2. Click en **Add New Project**
3. Seleccioná el repo `mis-gastos`
4. Click en **Deploy** (Vercel detecta automáticamente que es React)
5. ¡Listo! Te da un link tipo `https://mis-gastos.vercel.app`

### Paso 4 — Compartir con tu amigo
- Mandále el link por WhatsApp
- Él entra desde Chrome en Android
- Toca los **3 puntitos** → **"Agregar a pantalla de inicio"**
- ¡Aparece el ícono en el celular como una app!

---

## 📱 Instalar en iPhone
- Abrir el link en Safari
- Tocar el botón compartir (cuadrado con flecha)
- "Agregar a pantalla de inicio"

---

## 🛠 Correr localmente
```bash
npm install
npm start
```

## 📦 Compilar
```bash
npm run build
```
