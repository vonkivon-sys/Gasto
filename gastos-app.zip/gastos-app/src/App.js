import { useState, useEffect } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────
const EXPENSE_CATEGORIES = [
  { id: "food",          label: "Comida",      icon: "🍽️", color: "#FF6B6B" },
  { id: "transport",     label: "Transporte",  icon: "🚌", color: "#4ECDC4" },
  { id: "entertainment", label: "Ocio",        icon: "🎬", color: "#FFE66D" },
  { id: "health",        label: "Salud",       icon: "💊", color: "#A8E6CF" },
  { id: "shopping",      label: "Compras",     icon: "🛍️", color: "#DDA0DD" },
  { id: "housing",       label: "Hogar",       icon: "🏠", color: "#F0A500" },
  { id: "other",         label: "Otro",        icon: "📌", color: "#B0B0B0" },
];
const INCOME_CATEGORIES = [
  { id: "salary",       label: "Sueldo",    icon: "💼", color: "#4ADE80" },
  { id: "freelance",    label: "Freelance", icon: "💻", color: "#34D399" },
  { id: "bonus",        label: "Bono",      icon: "🎁", color: "#6EE7B7" },
  { id: "investment",   label: "Inversión", icon: "📈", color: "#86EFAC" },
  { id: "other_income", label: "Otro",      icon: "💰", color: "#BBF7D0" },
];

const fmt = (n) => new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", minimumFractionDigits: 0 }).format(n);
const todayStr = () => new Date().toISOString().split("T")[0];
const monthStr = () => new Date().toISOString().slice(0, 7);
const LS = { get: (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } }, set: (k, v) => localStorage.setItem(k, JSON.stringify(v)), del: (k) => localStorage.removeItem(k) };

// ─── Login Screen ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [mode, setMode] = useState("login"); // login | register
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");
  const [showPass, setShowPass] = useState(false);

  const submit = () => {
    if (!user.trim() || !pass.trim()) { setError("Completá todos los campos"); return; }
    const users = LS.get("users") || {};
    if (mode === "register") {
      if (users[user]) { setError("Ese usuario ya existe"); return; }
      users[user] = { password: pass, createdAt: new Date().toISOString() };
      LS.set("users", users);
      onLogin(user);
    } else {
      if (!users[user] || users[user].password !== pass) { setError("Usuario o contraseña incorrectos"); return; }
      onLogin(user);
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0F0F13", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24 }}>
      {/* Logo */}
      <div style={{ marginBottom: 40, textAlign: "center" }}>
        <div style={{ fontSize: 56, marginBottom: 12 }}>💸</div>
        <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: -1 }}>Mis Gastos</div>
        <div style={{ fontSize: 14, color: "#888", marginTop: 4 }}>Controlá tu plata fácil</div>
      </div>

      {/* Toggle */}
      <div style={{ display: "flex", background: "#1a1a24", borderRadius: 14, padding: 4, marginBottom: 28, width: "100%", maxWidth: 340, gap: 4 }}>
        {[["login", "Iniciar sesión"], ["register", "Registrarse"]].map(([m, label]) => (
          <button key={m} onClick={() => { setMode(m); setError(""); }}
            style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 14, background: mode === m ? "#4ADE80" : "transparent", color: mode === m ? "#0F0F13" : "#888", transition: "all .2s" }}>
            {label}
          </button>
        ))}
      </div>

      {/* Form */}
      <div style={{ width: "100%", maxWidth: 340 }}>
        <label style={lbl}>Usuario</label>
        <input style={inp} placeholder="tu_usuario" value={user}
          onChange={e => { setUser(e.target.value); setError(""); }}
          onKeyDown={e => e.key === "Enter" && submit()} autoCapitalize="none" autoCorrect="off" />

        <label style={lbl}>Contraseña</label>
        <div style={{ position: "relative", marginBottom: 8 }}>
          <input style={{ ...inp, marginBottom: 0, paddingRight: 48 }}
            type={showPass ? "text" : "password"} placeholder="••••••••" value={pass}
            onChange={e => { setPass(e.target.value); setError(""); }}
            onKeyDown={e => e.key === "Enter" && submit()} />
          <button onClick={() => setShowPass(v => !v)}
            style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", fontSize: 18, color: "#888" }}>
            {showPass ? "🙈" : "👁️"}
          </button>
        </div>

        {error && <div style={{ color: "#FF6B6B", fontSize: 13, marginBottom: 12, marginTop: 8 }}>⚠️ {error}</div>}

        <button onClick={submit}
          style={{ width: "100%", padding: 16, borderRadius: 14, border: "none", background: "linear-gradient(135deg,#4ADE80,#22C55E)", color: "#0F0F13", fontWeight: 800, fontSize: 16, cursor: "pointer", marginTop: 12 }}>
          {mode === "login" ? "Entrar →" : "Crear cuenta →"}
        </button>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);

  useEffect(() => {
    const saved = LS.get("session");
    if (saved) setCurrentUser(saved);
    setAuthReady(true);
  }, []);

  const login = (username) => {
    LS.set("session", username);
    setCurrentUser(username);
  };

  const logout = () => {
    LS.del("session");
    setCurrentUser(null);
  };

  if (!authReady) return null;
  if (!currentUser) return <LoginScreen onLogin={login} />;
  return <Tracker username={currentUser} onLogout={logout} />;
}

// ─── Tracker ──────────────────────────────────────────────────────────────────
function Tracker({ username, onLogout }) {
  const KEY_EXP = `expenses-${username}`;
  const KEY_INC = `incomes-${username}`;

  const [expenses, setExpenses] = useState(() => LS.get(KEY_EXP) || []);
  const [incomes, setIncomes]   = useState(() => LS.get(KEY_INC) || []);

  const [formType, setFormType] = useState("expense");
  const [form, setForm]         = useState({ description: "", amount: "", category: "food", date: todayStr() });
  const [editId, setEditId]     = useState(null);
  const [view, setView]         = useState("list");
  const [listTab, setListTab]   = useState("all");
  const [filterCat, setFilterCat] = useState("all");
  const [delConfirm, setDelConfirm] = useState(null);
  const [showLogout, setShowLogout] = useState(false);

  useEffect(() => { LS.set(KEY_EXP, expenses); }, [expenses]);
  useEffect(() => { LS.set(KEY_INC, incomes); }, [incomes]);

  const defCat = (t) => t === "income" ? "salary" : "food";
  const CATS   = formType === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
  const cat    = (id) => EXPENSE_CATEGORIES.find(c => c.id === id) || INCOME_CATEGORIES.find(c => c.id === id) || EXPENSE_CATEGORIES[6];

  const openAdd = (type) => { setFormType(type); setEditId(null); setForm({ description: "", amount: "", category: defCat(type), date: todayStr() }); setView("add"); };

  const save = () => {
    if (!form.description.trim() || !form.amount || isNaN(+form.amount)) return;
    const entry = { id: editId || Date.now(), ...form, amount: +form.amount };
    if (formType === "expense") setExpenses(p => editId ? p.map(e => e.id === editId ? entry : e) : [entry, ...p]);
    else                        setIncomes(p  => editId ? p.map(e => e.id === editId ? entry : e) : [entry, ...p]);
    setEditId(null); setView("list");
  };

  const startEdit = (item, type) => { setFormType(type); setEditId(item.id); setForm({ description: item.description, amount: String(item.amount), category: item.category, date: item.date }); setView("add"); };
  const remove    = (id, type)   => { if (type === "expense") setExpenses(p => p.filter(e => e.id !== id)); else setIncomes(p => p.filter(e => e.id !== id)); setDelConfirm(null); };

  // Totals
  const expMonth = expenses.filter(e => e.date.startsWith(monthStr())).reduce((s, e) => s + e.amount, 0);
  const incMonth = incomes.filter(e  => e.date.startsWith(monthStr())).reduce((s, e) => s + e.amount, 0);
  const balance  = incMonth - expMonth;
  const expAll   = expenses.reduce((s, e) => s + e.amount, 0);
  const incAll   = incomes.reduce((s, e)  => s + e.amount, 0);

  // List
  const allItems = [...expenses.map(e => ({ ...e, _t: "expense" })), ...incomes.map(e => ({ ...e, _t: "income" }))]
    .sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
  const visible  = allItems
    .filter(i => listTab === "all" ? true : listTab === "expenses" ? i._t === "expense" : i._t === "income")
    .filter(i => filterCat === "all" || i.category === filterCat);

  const byCatExp = EXPENSE_CATEGORIES.map(c => ({ ...c, total: expenses.filter(e => e.category === c.id).reduce((s, e) => s + e.amount, 0) })).filter(c => c.total > 0).sort((a, b) => b.total - a.total);
  const byCatInc = INCOME_CATEGORIES.map(c  => ({ ...c, total: incomes.filter(e => e.category === c.id).reduce((s, e) => s + e.amount, 0) })).filter(c => c.total > 0).sort((a, b) => b.total - a.total);
  const spendPct = incMonth > 0 ? Math.min(100, (expMonth / incMonth) * 100) : 0;

  return (
    <div style={{ minHeight: "100vh", background: "#0F0F13", color: "#F0EDE8", display: "flex", flexDirection: "column", maxWidth: 480, margin: "0 auto", position: "relative" }}>

      {/* HEADER */}
      <div style={{ padding: "20px 20px 14px", background: "linear-gradient(160deg,#1a1a24 0%,#0F0F13 100%)", borderBottom: "1px solid #1e1e2a" }}>

        {/* Top bar */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg,#4ADE80,#22C55E)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 15, color: "#0F0F13" }}>
              {username[0].toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize: 12, color: "#888" }}>Hola,</div>
              <div style={{ fontSize: 15, fontWeight: 700 }}>{username}</div>
            </div>
          </div>
          <button onClick={() => setShowLogout(v => !v)}
            style={{ background: "#1e1e2a", border: "none", color: "#888", borderRadius: 10, padding: "8px 12px", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            ⚙️
          </button>
        </div>

        {/* Logout dropdown */}
        {showLogout && (
          <div style={{ background: "#1e1e2a", borderRadius: 12, padding: 4, marginBottom: 12 }}>
            <button onClick={onLogout} style={{ width: "100%", padding: "12px 14px", background: "none", border: "none", color: "#FF6B6B", cursor: "pointer", fontWeight: 700, fontSize: 14, textAlign: "left", borderRadius: 10 }}>
              🚪 Cerrar sesión
            </button>
          </div>
        )}

        {/* Balance */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: "#888", letterSpacing: 2, textTransform: "uppercase", marginBottom: 2 }}>Balance del mes</div>
          <div style={{ fontSize: 34, fontWeight: 800, letterSpacing: -1, color: balance >= 0 ? "#4ADE80" : "#FF6B6B" }}>
            {balance >= 0 ? "+" : ""}{fmt(balance)}
          </div>
        </div>

        {/* Cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: incMonth > 0 ? 12 : 0 }}>
          <div style={{ background: "#4ADE8011", border: "1px solid #4ADE8033", borderRadius: 14, padding: "10px 14px" }}>
            <div style={{ fontSize: 11, color: "#4ADE80", marginBottom: 2, fontWeight: 600 }}>↑ INGRESOS</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#4ADE80" }}>{fmt(incMonth)}</div>
            <div style={{ fontSize: 11, color: "#4ADE8066" }}>este mes</div>
          </div>
          <div style={{ background: "#FF6B6B11", border: "1px solid #FF6B6B33", borderRadius: 14, padding: "10px 14px" }}>
            <div style={{ fontSize: 11, color: "#FF6B6B", marginBottom: 2, fontWeight: 600 }}>↓ GASTOS</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#FF6B6B" }}>{fmt(expMonth)}</div>
            <div style={{ fontSize: 11, color: "#FF6B6B66" }}>este mes</div>
          </div>
        </div>

        {incMonth > 0 && (
          <div style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#888", marginBottom: 4 }}>
              <span>% del ingreso gastado</span>
              <span style={{ color: spendPct > 90 ? "#FF6B6B" : "#4ADE80", fontWeight: 700 }}>{Math.round(spendPct)}%</span>
            </div>
            <div style={{ height: 7, background: "#2a2a36", borderRadius: 99, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${spendPct}%`, background: spendPct > 90 ? "linear-gradient(90deg,#FF6B6B,#FF4444)" : "linear-gradient(90deg,#4ADE80,#22C55E)", borderRadius: 99, transition: "width .6s ease" }} />
            </div>
          </div>
        )}

        {/* Nav */}
        <div style={{ display: "flex", gap: 6 }}>
          {[["list", "📋 Lista"], ["summary", "📊 Resumen"]].map(([v, label]) => (
            <button key={v} onClick={() => setView(v)}
              style={{ flex: 1, padding: "8px 0", borderRadius: 10, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600, background: view === v ? "#4ADE80" : "#1e1e2a", color: view === v ? "#0F0F13" : "#888", transition: "all .2s" }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ── ADD / EDIT ── */}
      {view === "add" && (
        <div style={{ padding: 20, flex: 1, overflowY: "auto" }}>
          <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 16 }}>{editId ? "Editar" : "Nuevo movimiento"}</div>

          {!editId && (
            <div style={{ display: "flex", background: "#1a1a24", borderRadius: 14, padding: 4, marginBottom: 20, gap: 4 }}>
              {[["expense", "↓ Gasto", "#FF6B6B", "#fff"], ["income", "↑ Ingreso", "#4ADE80", "#0F0F13"]].map(([t, label, bg, fg]) => (
                <button key={t} onClick={() => { setFormType(t); setForm(f => ({ ...f, category: defCat(t) })); }}
                  style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 14, background: formType === t ? bg : "transparent", color: formType === t ? fg : "#888", transition: "all .2s" }}>
                  {label}
                </button>
              ))}
            </div>
          )}

          <label style={lbl}>Descripción</label>
          <input style={inp} placeholder={formType === "income" ? "Sueldo enero, pago cliente..." : "¿En qué gastaste?"} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />

          <label style={lbl}>Monto ($)</label>
          <input style={{ ...inp, color: formType === "income" ? "#4ADE80" : "#FF6B6B", fontSize: 24, fontWeight: 800 }} type="number" placeholder="0" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />

          <label style={lbl}>Fecha</label>
          <input style={inp} type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />

          <label style={lbl}>Categoría</label>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, marginBottom: 28 }}>
            {CATS.map(c => (
              <button key={c.id} onClick={() => setForm(f => ({ ...f, category: c.id }))}
                style={{ padding: "10px 4px", borderRadius: 12, border: `2px solid ${form.category === c.id ? c.color : "transparent"}`, background: form.category === c.id ? c.color + "22" : "#1e1e2a", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <span style={{ fontSize: 20 }}>{c.icon}</span>
                <span style={{ fontSize: 10, color: form.category === c.id ? c.color : "#888", fontWeight: 600 }}>{c.label}</span>
              </button>
            ))}
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => { setView("list"); setEditId(null); }}
              style={{ flex: 1, padding: 14, borderRadius: 14, border: "1px solid #333", background: "transparent", color: "#888", fontWeight: 600, cursor: "pointer", fontSize: 15 }}>
              Cancelar
            </button>
            <button onClick={save}
              style={{ flex: 2, padding: 14, borderRadius: 14, border: "none", background: formType === "income" ? "linear-gradient(135deg,#4ADE80,#22C55E)" : "linear-gradient(135deg,#FF6B6B,#FF8E53)", color: formType === "income" ? "#0F0F13" : "#fff", fontWeight: 800, cursor: "pointer", fontSize: 15, opacity: (!form.description || !form.amount) ? 0.4 : 1 }}>
              {editId ? "Guardar" : formType === "income" ? "Agregar ingreso" : "Agregar gasto"}
            </button>
          </div>
        </div>
      )}

      {/* ── LIST ── */}
      {view === "list" && (
        <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px", paddingBottom: 100 }}>
          <div style={{ display: "flex", background: "#1a1a24", borderRadius: 12, padding: 3, marginBottom: 12, gap: 3 }}>
            {[["all", "Todos"], ["incomes", "↑ Ingresos"], ["expenses", "↓ Gastos"]].map(([t, label]) => (
              <button key={t} onClick={() => { setListTab(t); setFilterCat("all"); }}
                style={{ flex: 1, padding: "7px 0", borderRadius: 9, border: "none", cursor: "pointer", fontSize: 12, fontWeight: 700, background: listTab === t ? (t === "incomes" ? "#4ADE80" : t === "expenses" ? "#FF6B6B" : "#fff") : "transparent", color: listTab === t ? "#0F0F13" : "#888", transition: "all .2s" }}>
                {label}
              </button>
            ))}
          </div>

          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 10 }}>
            <button onClick={() => setFilterCat("all")} style={chip(filterCat === "all", "#888")}>Todos</button>
            {(listTab === "incomes" ? INCOME_CATEGORIES : listTab === "expenses" ? EXPENSE_CATEGORIES : [...EXPENSE_CATEGORIES, ...INCOME_CATEGORIES]).map(c => (
              <button key={c.id} onClick={() => setFilterCat(c.id)} style={chip(filterCat === c.id, c.color)}>{c.icon} {c.label}</button>
            ))}
          </div>

          {visible.length === 0 ? (
            <div style={{ textAlign: "center", padding: "50px 0", color: "#555" }}>
              <div style={{ fontSize: 40, marginBottom: 10 }}>📭</div>
              <div>Sin movimientos</div>
            </div>
          ) : visible.map(item => {
            const c = cat(item.category);
            const isInc = item._t === "income";
            return (
              <div key={`${item._t}-${item.id}`} style={{ background: "#1a1a24", borderRadius: 16, padding: "13px 14px", display: "flex", alignItems: "center", gap: 12, marginBottom: 10, border: delConfirm?.id === item.id ? "1px solid #FF6B6B44" : `1px solid ${isInc ? "#4ADE8022" : "transparent"}` }}>
                <div style={{ width: 44, height: 44, borderRadius: 12, background: c.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0, position: "relative" }}>
                  {c.icon}
                  <span style={{ position: "absolute", bottom: -4, right: -4, fontSize: 10, background: isInc ? "#4ADE80" : "#FF6B6B", borderRadius: "50%", width: 16, height: 16, display: "flex", alignItems: "center", justifyContent: "center", color: "#0F0F13", fontWeight: 900 }}>
                    {isInc ? "+" : "−"}
                  </span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 15, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.description}</div>
                  <div style={{ fontSize: 12, color: "#888", marginTop: 2 }}>{c.label} · {item.date}</div>
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 16, color: isInc ? "#4ADE80" : "#FF6B6B" }}>{isInc ? "+" : "−"}{fmt(item.amount)}</div>
                  <div style={{ display: "flex", gap: 5, justifyContent: "flex-end", marginTop: 4 }}>
                    <button onClick={() => startEdit(item, item._t)} style={{ fontSize: 14, background: "none", border: "none", cursor: "pointer", color: "#888", padding: "2px 3px" }}>✏️</button>
                    {delConfirm?.id === item.id ? (
                      <>
                        <button onClick={() => remove(item.id, item._t)} style={{ fontSize: 11, background: "#FF6B6B", border: "none", cursor: "pointer", color: "#fff", padding: "2px 8px", borderRadius: 6, fontWeight: 700 }}>Sí</button>
                        <button onClick={() => setDelConfirm(null)} style={{ fontSize: 11, background: "#333", border: "none", cursor: "pointer", color: "#aaa", padding: "2px 8px", borderRadius: 6 }}>No</button>
                      </>
                    ) : (
                      <button onClick={() => setDelConfirm({ id: item.id })} style={{ fontSize: 14, background: "none", border: "none", cursor: "pointer", color: "#888", padding: "2px 3px" }}>🗑️</button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── SUMMARY ── */}
      {view === "summary" && (
        <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px", paddingBottom: 100 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 18 }}>
            {[
              ["Ingresos mes", fmt(incMonth), "#4ADE80"],
              ["Gastos mes", fmt(expMonth), "#FF6B6B"],
              ["Balance total", fmt(incAll - expAll), incAll >= expAll ? "#4ADE80" : "#FF6B6B"],
              ["Movimientos", `${expenses.length + incomes.length}`, "#DDA0DD"],
            ].map(([label, val, color]) => (
              <div key={label} style={{ background: "#1a1a24", borderRadius: 14, padding: "14px 12px" }}>
                <div style={{ fontSize: 11, color: "#888", marginBottom: 5, textTransform: "uppercase", letterSpacing: 1 }}>{label}</div>
                <div style={{ fontSize: 17, fontWeight: 700, color }}>{val}</div>
              </div>
            ))}
          </div>

          {byCatInc.length > 0 && <>
            <div style={{ fontSize: 12, color: "#4ADE80", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1, fontWeight: 700 }}>↑ Ingresos por categoría</div>
            {byCatInc.map(c => <CatBar key={c.id} c={c} total={incAll} />)}
            <div style={{ marginBottom: 16 }} />
          </>}

          {byCatExp.length > 0 && <>
            <div style={{ fontSize: 12, color: "#FF6B6B", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1, fontWeight: 700 }}>↓ Gastos por categoría</div>
            {byCatExp.map(c => <CatBar key={c.id} c={c} total={expAll} />)}
          </>}
        </div>
      )}

      {/* FAB */}
      {view !== "add" && (
        <div style={{ position: "fixed", bottom: 24, right: "calc(50% - min(240px, 50vw) + 16px)", display: "flex", flexDirection: "column", gap: 10, zIndex: 100 }}>
          <button onClick={() => openAdd("income")} title="Agregar ingreso"
            style={{ width: 52, height: 52, borderRadius: "50%", background: "linear-gradient(135deg,#4ADE80,#22C55E)", border: "none", cursor: "pointer", fontSize: 18, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 6px 20px #4ADE8055", color: "#0F0F13" }}>
            +$
          </button>
          <button onClick={() => openAdd("expense")} title="Agregar gasto"
            style={{ width: 52, height: 52, borderRadius: "50%", background: "linear-gradient(135deg,#FF6B6B,#FF8E53)", border: "none", cursor: "pointer", fontSize: 18, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 6px 20px #FF6B6B55", color: "#fff" }}>
            −$
          </button>
        </div>
      )}
    </div>
  );
}

function CatBar({ c, total }) {
  const pct = total > 0 ? (c.total / total) * 100 : 0;
  return (
    <div style={{ background: "#1a1a24", borderRadius: 14, padding: "11px 13px", marginBottom: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 7 }}>
        <span style={{ fontSize: 14 }}>{c.icon} {c.label}</span>
        <span style={{ fontWeight: 700, color: c.color }}>{fmt(c.total)}</span>
      </div>
      <div style={{ height: 6, background: "#2a2a36", borderRadius: 99, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, background: c.color, borderRadius: 99, transition: "width .6s ease" }} />
      </div>
      <div style={{ fontSize: 11, color: "#666", marginTop: 4 }}>{pct.toFixed(1)}%</div>
    </div>
  );
}

const lbl  = { display: "block", fontSize: 12, color: "#888", marginBottom: 6, letterSpacing: 1, textTransform: "uppercase" };
const inp  = { width: "100%", padding: "12px 14px", borderRadius: 12, border: "1px solid #2a2a36", background: "#1a1a24", color: "#F0EDE8", fontSize: 15, marginBottom: 16, boxSizing: "border-box", outline: "none", fontFamily: "inherit" };
const chip = (active, color) => ({ padding: "6px 13px", borderRadius: 20, border: "none", cursor: "pointer", fontSize: 12, whiteSpace: "nowrap", fontWeight: 600, flexShrink: 0, background: active ? color + "33" : "#1e1e2a", color: active ? color : "#888", outline: active ? `1px solid ${color}55` : "none" });
